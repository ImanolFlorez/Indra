from django.http.response import HttpResponse, JsonResponse
from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_exempt
# Create your views here.

def inicio(request):
    return render(request,"index.html",{})

@csrf_exempt
def Multiplicar(request):
    if request.method == 'POST' and request.is_ajax():
        data = json.loads(request.body)
        numero1=data["Number1"]
        numero2=data["Number2"]
        print(numero1)
        print(numero2)
        resultado=int(numero1)*int(numero2)
        res=json.dumps({"Resultado":resultado},ensure_ascii=False)
    return HttpResponse(res)
